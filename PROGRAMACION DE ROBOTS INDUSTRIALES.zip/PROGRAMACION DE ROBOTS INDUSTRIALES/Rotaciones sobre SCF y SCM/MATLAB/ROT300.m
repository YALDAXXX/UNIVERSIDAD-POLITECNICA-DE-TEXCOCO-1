% Rotación en Z de 300°
clc;
clear all;
close all;
grid on;
view(135,22);
axis([-1 1 -1 1 -1 1]);
line([-1 1], [0 0],[0 0],'color','g','linewidth',2);
line([0 0], [-1 1],[0 0],'color','y','linewidth',2);
line([0 0], [0 0],[-1 1],'color','b','linewidth',2);
line([0 1],[0 0], [0 0],'color','g','linewidth',4);
line([0 0],[0 1], [0 0],'color','y','linewidth',4);
line([0 0],[0 0], [0 1],'color','b','linewidth',4);
pause();

for i=0:300
    xu=cosd(i);
    yu=sind(i);
    zu=0;
    xv=-sind(i);
    yv=cosd(i);
    zv=0;
    xw=0;
    yw=0;
    zw=1;
    
    Rz= [xu xv xw; yu yv yw; zu zv zw];
    
    grid on;
    view(135,22);
    axis([-1 1 -1 1 -1 1]);
    line([-1 1], [0 0],[0 0],'color','g','linewidth',2);
    line([0 0], [-1 1],[0 0],'color','y','linewidth',2);
    line([0 0], [0 0],[-1 1],'color','b','linewidth',2);
    line ([0 xu],[0 yu], [0 zu],'color','g','linewidth',4);
    line ([0 xv],[0 yv], [0 zv],'color','y','linewidth',4);
    line ([0 xw],[0 yw], [0 zw],'color','b','linewidth',4);
    
    pause(0.01);
    if i<300
        clf;
    end
end
pause();
