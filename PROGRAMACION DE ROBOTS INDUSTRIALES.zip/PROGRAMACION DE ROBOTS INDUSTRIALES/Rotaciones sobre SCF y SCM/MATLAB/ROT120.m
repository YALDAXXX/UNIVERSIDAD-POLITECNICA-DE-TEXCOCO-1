% Rotación en w de 120°
clc;
clear all;
close all;
grid on;
view(135,22);
axis([-1 1 -1 1 -1 1]);
line([-1 1], [0 0],[0 0],'color','r','linewidth',2);
line([0 0], [-1 1],[0 0],'color','g','linewidth',2);
line([0 0], [0 0],[-1 1],'color','b','linewidth',2);

for i=0:120
    xu=cosd(i);  yu=0;  zu=sind(i);
    xv=0;        yv=1;  zv=0;
    xw=-sind(i); yw=0;  zw=cosd(i);
    
    Rw = [xu xv xw; yu yv yw; zu zv zw];

    clf;
    grid on;
    view(135,22);
    axis([-1 1 -1 1 -1 1]);
    line([-1 1], [0 0],[0 0],'color','r','linewidth',2);
    line([0 0], [-1 1],[0 0],'color','g','linewidth',2);
    line([0 0], [0 0],[-1 1],'color','b','linewidth',2);

    line([0 xu], [0 yu], [0 zu],'color','r','linewidth',4);
    line([0 xv], [0 yv], [0 zv],'color','g','linewidth',4);
    line([0 xw], [0 yw], [0 zw],'color','b','linewidth',4);

    pause(0.0001);
end
pause();
