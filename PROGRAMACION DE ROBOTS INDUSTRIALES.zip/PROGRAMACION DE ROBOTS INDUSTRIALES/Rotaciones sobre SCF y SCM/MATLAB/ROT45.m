% Rotación en U de 45°
clc;
clear all;
close all;
grid on;
view(135,22);
axis([-1 1 -1 1 -1 1]);
line([-1 1], [0 0],[0 0],'color','g','linewidth',2);
line([0 0], [-1 1],[0 0],'color','y','linewidth',2);
line([0 0], [0 0],[-1 1],'color','b','linewidth',2);

for i=0:45
    xu=1;  yu=0;   zu=0;
    xv=0;  yv=cosd(i);  zv=sind(i);
    xw=0;  yw=-sind(i);  zw=cosd(i);
    
    Ru = [xu xv xw; yu yv yw; zu zv zw];

    clf;
    grid on;
    view(135,22);
    axis([-1 1 -1 1 -1 1]);
    line([-1 1], [0 0],[0 0],'color','g','linewidth',2);
    line([0 0], [-1 1],[0 0],'color','y','linewidth',2);
    line([0 0], [0 0],[-1 1],'color','b','linewidth',2);

    line([0 xu], [0 yu], [0 zu],'color','g','linewidth',4);
    line([0 xv], [0 yv], [0 zv],'color','y','linewidth',4);
    line([0 xw], [0 yw], [0 zw],'color','b','linewidth',4);

    pause(0.01);
end
pause();
