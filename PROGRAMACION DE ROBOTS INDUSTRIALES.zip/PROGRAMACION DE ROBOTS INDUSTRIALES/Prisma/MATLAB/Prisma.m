clc
clear all
close
axis([-5 15 -5 15 -5 15]);
grid on;

view(135,22); %Vista que se tendr? de la fig. en el ploteo.
% ----- Aristas inferiores -----
line([0 5], [0 0], [0 0], 'linewidth', 4, 'color', 'y');    
line([0 5], [5 5], [0 0], 'linewidth', 4, 'color', 'y'); 
line([0 0], [0 5], [0 0], 'linewidth', 4, 'color', 'y');   
line([5 5], [0 5], [0 0], 'linewidth', 4, 'color', 'y');   

% ----- Aristas superiores -----
line([0 5], [0 0], [2 2], 'linewidth', 4, 'color', 'y'); 
line([0 5], [5 5], [2 2], 'linewidth', 4, 'color', 'y'); 
line([0 0], [0 5], [2 2], 'linewidth', 4, 'color', 'y'); 
line([5 5], [0 5], [2 2], 'linewidth', 4, 'color', 'y');

% ----- Aristas verticales -----
line([0 0], [0 0], [0 2], 'linewidth', 4, 'color', 'y');   
line([5 5], [0 0], [0 2], 'linewidth', 4, 'color', 'y');  
line([0 0], [5 5], [0 2], 'linewidth', 4, 'color', 'y'); 
line([5 5], [5 5], [0 2], 'linewidth', 4, 'color', 'y');   

% ----- Aristas triangulares -----
line([0 0], [0 0], [2 10], 'linewidth', 4, 'color', 'y');
line([5 0], [0 0], [2 10], 'linewidth', 4, 'color', 'y');
line([5 0], [5 5], [2 10], 'linewidth', 4, 'color', 'y'); 
line([0 0], [5 5], [2 10], 'linewidth', 4, 'color', 'y');
line([0 0], [5 0], [10 10], 'linewidth', 4, 'color', 'y');  

% ----- Sistema de referencia -----
line([0 1], [0 0], [0 0], 'linewidth', 4, 'color', 'b'); % Eje X en azul
line([0 0], [0 1], [0 0], 'linewidth', 4, 'color', 'g'); % Eje Y en verde
line([0 0], [0 0], [0 1], 'linewidth', 4, 'color', 'r'); % Eje Z en rojo


%-----Rotacion de 90 en Ru-----
for i=0:90; 
xu=1;
yu=0;
zu=0;
xv=0;
yv=cosd(i);
zv=sind(i);
xw=0;
yw=-sind(i);
zw=cosd(i);
t1=0;
t2=0;
t3=0;
t4=1;
a1=0;
a2=0;
a3=0;

Ru= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

grid on
view(135,22) 
axis([-5 15 -5 15 -5 15]);

line ([0 xu],[0 yu], [0 zu],'color','b','linewidth',4)
line ([0 xv],[0 yv], [0 zv],'color','g','linewidth',4)
line ([0 xw],[0 yw], [0 zw],'color','r','linewidth',4)

pause (0.0001); 
    if i < 90
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Rotacion de 90 en Rv-----
for i=0:90;
xu=cosd(i);
yu=0;
zu=-sind(i);
xv=0;
yv=1;
zv=0;
xw=sind(i);
yw=0;
zw=cosd(i);
t1=0;
t2=0;
t3=0;
t4=1;
a1=0;
a2=0;
a3=0;

Rv= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rra=Ru*Rv;

grid on
view(135,22) 
axis([-5 15 -5 15 -5 15]);

%Ploteo de las l?neas que representan los ejes moviles utilizando los valores arrojados en el ciclo for.
line ([0 rra(1,1)],[0 rra(2,1)], [0 rra(3,1)],'color','b','linewidth',4)
line ([0 rra(1,2)],[0 rra(2,2)], [0 rra(3,2)],'color','g','linewidth',4)
line ([0 rra(1,3)],[0 rra(2,3)], [0 rra(3,3)],'color','r','linewidth',4)

pause (0.00001); 
    if i < 90
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Traslacion de 5 en Rw-----
for i=0:5;
xu=cosd(i);
yu=sind(i);
zu=0;
xv=-sind(i);
yv=cosd(i);
zv=0;
xw=0;
yw=0;
zw=1;
t1=0;
t2=0;
t3=i;
t4=1;
a1=0;
a2=0;
a3=0;

Rw= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];
rrb = rra*Rw;  
grid on
view(135,22); 
axis([-5 15 -5 15 -5 15]);

line([rrb(1,4), rrb(1,4) + rrb(1,1)], [rrb(2,4), rrb(2,4) + rrb(2,1)], [rrb(3,4), rrb(3,4) + rrb(3,1)], 'color', 'b', 'linewidth', 4);
line([rrb(1,4), rrb(1,4) + rrb(1,2)], [rrb(2,4), rrb(2,4) + rrb(2,2)], [rrb(3,4), rrb(3,4) + rrb(3,2)], 'color', 'g', 'linewidth', 4);
line([rrb(1,4), rrb(1,4) + rrb(1,3)], [rrb(2,4), rrb(2,4) + rrb(2,3)], [rrb(3,4), rrb(3,4) + rrb(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.5);
    if i < 5
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Rotacion de 90 en Rv-----
for i=0:90; 
xu=cosd(i);
yu=0;
zu=-sind(i);
xv=0;
yv=1;
zv=0;
xw=sind(i);
yw=0;
zw=cosd(i);
t1=0;
t2=0;
t3=0;
t4=1;
a1=0;
a2=0;
a3=0;

Rv= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrc=rrb*Rv;

grid on
view(135,22) 
axis([-5 15 -5 15 -5 15]);

line([rrc(1,4), rrc(1,4) + rrc(1,1)], [rrc(2,4), rrc(2,4) + rrc(2,1)], [rrc(3,4), rrc(3,4) + rrc(3,1)], 'color', 'b', 'linewidth', 4);
line([rrc(1,4), rrc(1,4) + rrc(1,2)], [rrc(2,4), rrc(2,4) + rrc(2,2)], [rrc(3,4), rrc(3,4) + rrc(3,2)], 'color', 'g', 'linewidth', 4);
line([rrc(1,4), rrc(1,4) + rrc(1,3)], [rrc(2,4), rrc(2,4) + rrc(2,3)], [rrc(3,4), rrc(3,4) + rrc(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.00001); 
    if i < 90
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Traslacion de 5 en Rw-----
for i=0:5;
xu=cosd(i);
yu=sind(i);
zu=0;
xv=-sind(i);
yv=cosd(i);
zv=0;
xw=0;
yw=0;
zw=1;
t1=0;
t2=0;
t3=i;
t4=1;
a1=0;
a2=0;
a3=0;

Rw= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrd = rrc*Rw; 

grid on
view(135,22); 
axis([-5 15 -5 15 -5 15]);

line([rrd(1,4), rrd(1,4) + rrd(1,1)], [rrd(2,4), rrd(2,4) + rrd(2,1)], [rrd(3,4), rrd(3,4) + rrd(3,1)], 'color', 'b', 'linewidth', 4);
line([rrd(1,4), rrd(1,4) + rrd(1,2)], [rrd(2,4), rrd(2,4) + rrd(2,2)], [rrd(3,4), rrd(3,4) + rrd(3,2)], 'color', 'g', 'linewidth', 4);
line([rrd(1,4), rrd(1,4) + rrd(1,3)], [rrd(2,4), rrd(2,4) + rrd(2,3)], [rrd(3,4), rrd(3,4) + rrd(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.5);
    if i < 5
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Rotacion de 90 en Rv-----
for i=0:90; 
xu=cosd(i);
yu=0;
zu=-sind(i);
xv=0;
yv=1;
zv=0;
xw=sind(i);
yw=0;
zw=cosd(i);
t1=0;
t2=0;
t3=0;
t4=1;
a1=0;
a2=0;
a3=0;

Rv= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rre=rrd*Rv;

grid on
view(135,22)
axis([-5 15 -5 15 -5 15]);

line([rre(1,4), rre(1,4) + rre(1,1)], [rre(2,4), rre(2,4) + rre(2,1)], [rre(3,4), rre(3,4) + rre(3,1)], 'color', 'b', 'linewidth', 4);
line([rre(1,4), rre(1,4) + rre(1,2)], [rre(2,4), rre(2,4) + rre(2,2)], [rre(3,4), rre(3,4) + rre(3,2)], 'color', 'g', 'linewidth', 4);
line([rre(1,4), rre(1,4) + rre(1,3)], [rre(2,4), rre(2,4) + rre(2,3)], [rre(3,4), rre(3,4) + rre(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.00001); 
    if i < 90
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Traslacion de 5 en Rw-----
for i=0:5;
xu=cosd(i);
yu=sind(i);
zu=0;
xv=-sind(i);
yv=cosd(i);
zv=0;
xw=0;
yw=0;
zw=1;
t1=0;
t2=0;
t3=i;
t4=1;
a1=0;
a2=0;
a3=0;

Rw= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrf = rre*Rw;  

grid on 
view(135,22);
axis([-5 15 -5 15 -5 15]);

line([rrf(1,4), rrf(1,4) + rrf(1,1)], [rrf(2,4), rrf(2,4) + rrf(2,1)], [rrf(3,4), rrf(3,4) + rrf(3,1)], 'color', 'b', 'linewidth', 4);
line([rrf(1,4), rrf(1,4) + rrf(1,2)], [rrf(2,4), rrf(2,4) + rrf(2,2)], [rrf(3,4), rrf(3,4) + rrf(3,2)], 'color', 'g', 'linewidth', 4);
line([rrf(1,4), rrf(1,4) + rrf(1,3)], [rrf(2,4), rrf(2,4) + rrf(2,3)], [rrf(3,4), rrf(3,4) + rrf(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.5);

    if i < 5
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Rotacion de 90 en Rv-----
for i=0:90; 
xu=cosd(i);
yu=0;
zu=-sind(i);
xv=0;
yv=1;
zv=0;
xw=sind(i);
yw=0;
zw=cosd(i);
t1=0;
t2=0;
t3=0;
t4=1;
a1=0;
a2=0;
a3=0;

Rv= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrg=rrf*Rv;

grid on
view(135,22)
axis([-5 15 -5 15 -5 15]);

line([rrg(1,4), rrg(1,4) + rrg(1,1)], [rrg(2,4), rrg(2,4) + rrg(2,1)], [rrg(3,4), rrg(3,4) + rrg(3,1)], 'color', 'b', 'linewidth', 4);
line([rrg(1,4), rrg(1,4) + rrg(1,2)], [rrg(2,4), rrg(2,4) + rrg(2,2)], [rrg(3,4), rrg(3,4) + rrg(3,2)], 'color', 'g', 'linewidth', 4);
line([rrg(1,4), rrg(1,4) + rrg(1,3)], [rrg(2,4), rrg(2,4) + rrg(2,3)], [rrg(3,4), rrg(3,4) + rrg(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.00001);
    if i < 90
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Traslacion de 5 en Rw-----
for i=0:5;
xu=cosd(i);
yu=sind(i);
zu=0;
xv=-sind(i);
yv=cosd(i);
zv=0;
xw=0;
yw=0;
zw=1;
t1=0;
t2=0;
t3=i;
t4=1;
a1=0;
a2=0;
a3=0;

Rw= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrh = rrg*Rw;  

grid on 
view(135,22); 
axis([-5 15 -5 15 -5 15]);

line([rrh(1,4), rrh(1,4) + rrh(1,1)], [rrh(2,4), rrh(2,4) + rrh(2,1)], [rrh(3,4), rrh(3,4) + rrh(3,1)], 'color', 'b', 'linewidth', 4);
line([rrh(1,4), rrh(1,4) + rrh(1,2)], [rrh(2,4), rrh(2,4) + rrh(2,2)], [rrh(3,4), rrh(3,4) + rrh(3,2)], 'color', 'g', 'linewidth', 4);
line([rrh(1,4), rrh(1,4) + rrh(1,3)], [rrh(2,4), rrh(2,4) + rrh(2,3)], [rrh(3,4), rrh(3,4) + rrh(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.5); 
    if i < 5
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Rotacion de 270 en Ru-----
for i=0:270; 
xu=1;
yu=0;
zu=0;
xv=0;
yv=cosd(i);
zv=sind(i);
xw=0;
yw=-sind(i);
zw=cosd(i);
t1=0;
t2=0;
t3=0;
t4=1;
a1=0;
a2=0;
a3=0;

Ru= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rri = rrh*Ru;

grid on
view(135,22)
axis([-5 15 -5 15 -5 15]);

line([rri(1,4), rri(1,4) + rri(1,1)], [rri(2,4), rri(2,4) + rri(2,1)], [rri(3,4), rri(3,4) + rri(3,1)], 'color', 'b', 'linewidth', 4);
line([rri(1,4), rri(1,4) + rri(1,2)], [rri(2,4), rri(2,4) + rri(2,2)], [rri(3,4), rri(3,4) + rri(3,2)], 'color', 'g', 'linewidth', 4);
line([rri(1,4), rri(1,4) + rri(1,3)], [rri(2,4), rri(2,4) + rri(2,3)], [rri(3,4), rri(3,4) + rri(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.00001);
    if i < 270
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Traslacion de 1 en Rw-----
for i=0:1;
xu=cosd(i);
yu=sind(i);
zu=0;
xv=-sind(i);
yv=cosd(i);
zv=0;
xw=0;
yw=0;
zw=1;
t1=0;
t2=0;
t3=i;
t4=1;
a1=0;
a2=0;
a3=0;

Rw= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrj = rri*Rw; 

grid on
view(135,22); 
axis([-5 15 -5 15 -5 15]);

line([rrj(1,4), rrj(1,4) + rrj(1,1)], [rrj(2,4), rrj(2,4) + rrj(2,1)], [rrj(3,4), rrj(3,4) + rrj(3,1)], 'color', 'b', 'linewidth', 4);
line([rrj(1,4), rrj(1,4) + rrj(1,2)], [rrj(2,4), rrj(2,4) + rrj(2,2)], [rrj(3,4), rrj(3,4) + rrj(3,2)], 'color', 'g', 'linewidth', 4);
line([rrj(1,4), rrj(1,4) + rrj(1,3)], [rrj(2,4), rrj(2,4) + rrj(2,3)], [rrj(3,4), rrj(3,4) + rrj(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.5);
    if i < 1
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Rotacion de 90 en Ru-----
for i=0:90; 
xu=1;
yu=0;
zu=0;
xv=0;
yv=cosd(i);
zv=sind(i);
xw=0;
yw=-sind(i);
zw=cosd(i);
t1=0;
t2=0;
t3=0;
t4=1;
a1=0;
a2=0;
a3=0;

Ru= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrk = rrj*Ru;

grid on
view(135,22) 
axis([-5 15 -5 15 -5 15]);

line([rrk(1,4), rrk(1,4) + rrk(1,1)], [rrk(2,4), rrk(2,4) + rrk(2,1)], [rrk(3,4), rrk(3,4) + rrk(3,1)], 'color', 'b', 'linewidth', 4);
line([rrk(1,4), rrk(1,4) + rrk(1,2)], [rrk(2,4), rrk(2,4) + rrk(2,2)], [rrk(3,4), rrk(3,4) + rrk(3,2)], 'color', 'g', 'linewidth', 4);
line([rrk(1,4), rrk(1,4) + rrk(1,3)], [rrk(2,4), rrk(2,4) + rrk(2,3)], [rrk(3,4), rrk(3,4) + rrk(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.00001);
    if i < 90
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Rotacion de 90 en Rv-----
for i=0:90; 
xu=cosd(i);
yu=0;
zu=-sind(i);
xv=0;
yv=1;
zv=0;
xw=sind(i);
yw=0;
zw=cosd(i);
t1=0;
t2=0;
t3=0;
t4=1;
a1=0;
a2=0;
a3=0;

Rv= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrl=rrk*Rv;

grid on
view(135,22)
axis([-5 15 -5 15 -5 15]);

line([rrl(1,4), rrl(1,4) + rrl(1,1)], [rrl(2,4), rrl(2,4) + rrl(2,1)], [rrl(3,4), rrl(3,4) + rrl(3,1)], 'color', 'b', 'linewidth', 4);
line([rrl(1,4), rrl(1,4) + rrl(1,2)], [rrl(2,4), rrl(2,4) + rrl(2,2)], [rrl(3,4), rrl(3,4) + rrl(3,2)], 'color', 'g', 'linewidth', 4);
line([rrl(1,4), rrl(1,4) + rrl(1,3)], [rrl(2,4), rrl(2,4) + rrl(2,3)], [rrl(3,4), rrl(3,4) + rrl(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.00001); 
    if i < 90
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Traslacion de 5 en Rw-----
for i=0:5;
xu=cosd(i);
yu=sind(i);
zu=0;
xv=-sind(i);
yv=cosd(i);
zv=0;
xw=0;
yw=0;
zw=1;
t1=0;
t2=0;
t3=i;
t4=1;
a1=0;
a2=0;
a3=0;

Rw= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrm = rrl*Rw; 

grid on 
view(135,22); 
axis([-5 15 -5 15 -5 15]);

line([rrm(1,4), rrm(1,4) + rrm(1,1)], [rrm(2,4), rrm(2,4) + rrm(2,1)], [rrm(3,4), rrm(3,4) + rrm(3,1)], 'color', 'b', 'linewidth', 4);
line([rrm(1,4), rrm(1,4) + rrm(1,2)], [rrm(2,4), rrm(2,4) + rrm(2,2)], [rrm(3,4), rrm(3,4) + rrm(3,2)], 'color', 'g', 'linewidth', 4);
line([rrm(1,4), rrm(1,4) + rrm(1,3)], [rrm(2,4), rrm(2,4) + rrm(2,3)], [rrm(3,4), rrm(3,4) + rrm(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.5);
    if i < 5
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Rotacion de 90 en Rv-----
for i=0:90;
xu=cosd(i);
yu=0;
zu=-sind(i);
xv=0;
yv=1;
zv=0;
xw=sind(i);
yw=0;
zw=cosd(i);
t1=0;
t2=0;
t3=0;
t4=1;
a1=0;
a2=0;
a3=0;

Rv= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrn=rrm*Rv;

grid on
view(135,22) 
axis([-5 15 -5 15 -5 15]);

line([rrn(1,4), rrn(1,4) + rrn(1,1)], [rrn(2,4), rrn(2,4) + rrn(2,1)], [rrn(3,4), rrn(3,4) + rrn(3,1)], 'color', 'b', 'linewidth', 4);
line([rrn(1,4), rrn(1,4) + rrn(1,2)], [rrn(2,4), rrn(2,4) + rrn(2,2)], [rrn(3,4), rrn(3,4) + rrn(3,2)], 'color', 'g', 'linewidth', 4);
line([rrn(1,4), rrn(1,4) + rrn(1,3)], [rrn(2,4), rrn(2,4) + rrn(2,3)], [rrn(3,4), rrn(3,4) + rrn(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.00001);
    if i < 90
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Traslacion de 5 en Rw-----
for i=0:5;
xu=cosd(i);
yu=sind(i);
zu=0;
xv=-sind(i);
yv=cosd(i);
zv=0;
xw=0;
yw=0;
zw=1;
t1=0;
t2=0;
t3=i;
t4=1;
a1=0;
a2=0;
a3=0;

Rw= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rro = rrn*Rw;  

grid on 
view(135,22); 
axis([-5 15 -5 15 -5 15]);

line([rro(1,4), rro(1,4) + rro(1,1)], [rro(2,4), rro(2,4) + rro(2,1)], [rro(3,4), rro(3,4) + rro(3,1)], 'color', 'b', 'linewidth', 4);
line([rro(1,4), rro(1,4) + rro(1,2)], [rro(2,4), rro(2,4) + rro(2,2)], [rro(3,4), rro(3,4) + rro(3,2)], 'color', 'g', 'linewidth', 4);
line([rro(1,4), rro(1,4) + rro(1,3)], [rro(2,4), rro(2,4) + rro(2,3)], [rro(3,4), rro(3,4) + rro(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.5);
    if i < 5
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Rotacion de 90 en Rv-----
for i=0:90; 
xu=cosd(i);
yu=0;
zu=-sind(i);
xv=0;
yv=1;
zv=0;
xw=sind(i);
yw=0;
zw=cosd(i);
t1=0;
t2=0;
t3=0;
t4=1;
a1=0;
a2=0;
a3=0;

Rv= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrp=rro*Rv;

grid on
view(135,22) 
axis([-5 15 -5 15 -5 15]);

line([rrp(1,4), rrp(1,4) + rrp(1,1)], [rrp(2,4), rrp(2,4) + rrp(2,1)], [rrp(3,4), rrp(3,4) + rrp(3,1)], 'color', 'b', 'linewidth', 4);
line([rrp(1,4), rrp(1,4) + rrp(1,2)], [rrp(2,4), rrp(2,4) + rrp(2,2)], [rrp(3,4), rrp(3,4) + rrp(3,2)], 'color', 'g', 'linewidth', 4);
line([rrp(1,4), rrp(1,4) + rrp(1,3)], [rrp(2,4), rrp(2,4) + rrp(2,3)], [rrp(3,4), rrp(3,4) + rrp(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.00001); 
    if i < 90
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Traslacion de 5 en Rw-----
for i=0:5;
xu=cosd(i);
yu=sind(i);
zu=0;
xv=-sind(i);
yv=cosd(i);
zv=0;
xw=0;
yw=0;
zw=1;
t1=0;
t2=0;
t3=i;
t4=1;
a1=0;
a2=0;
a3=0;

Rw= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrq = rrp*Rw;  

grid on
view(135,22);
axis([-5 15 -5 15 -5 15]);

line([rrq(1,4), rrq(1,4) + rrq(1,1)], [rrq(2,4), rrq(2,4) + rrq(2,1)], [rrq(3,4), rrq(3,4) + rrq(3,1)], 'color', 'b', 'linewidth', 4);
line([rrq(1,4), rrq(1,4) + rrq(1,2)], [rrq(2,4), rrq(2,4) + rrq(2,2)], [rrq(3,4), rrq(3,4) + rrq(3,2)], 'color', 'g', 'linewidth', 4);
line([rrq(1,4), rrq(1,4) + rrq(1,3)], [rrq(2,4), rrq(2,4) + rrq(2,3)], [rrq(3,4), rrq(3,4) + rrq(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.5);
    if i < 5
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Rotacion de 90 en Rv-----
for i=0:90; 
xu=cosd(i);
yu=0;
zu=-sind(i);
xv=0;
yv=1;
zv=0;
xw=sind(i);
yw=0;
zw=cosd(i);
t1=0;
t2=0;
t3=0;
t4=1;
a1=0;
a2=0;
a3=0;

Rv= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrr=rrq*Rv;
grid on
view(135,22)
axis([-5 15 -5 15 -5 15]);

line([rrr(1,4), rrr(1,4) + rrr(1,1)], [rrr(2,4), rrr(2,4) + rrr(2,1)], [rrr(3,4), rrr(3,4) + rrr(3,1)], 'color', 'b', 'linewidth', 4);
line([rrr(1,4), rrr(1,4) + rrr(1,2)], [rrr(2,4), rrr(2,4) + rrr(2,2)], [rrr(3,4), rrr(3,4) + rrr(3,2)], 'color', 'g', 'linewidth', 4);
line([rrr(1,4), rrr(1,4) + rrr(1,3)], [rrr(2,4), rrr(2,4) + rrr(2,3)], [rrr(3,4), rrr(3,4) + rrr(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.00001); 
    if i < 90
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Tralacion de 5 en Rw-----
for i=0:5;
xu=cosd(i);
yu=sind(i);
zu=0;
xv=-sind(i);
yv=cosd(i);
zv=0;
xw=0;
yw=0;
zw=1;
t1=0;
t2=0;
t3=i;
t4=1;
a1=0;
a2=0;
a3=0;

Rw= [xu xv xw t1;
	yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrs = rrr*Rw;  

grid on 
view(135,22);
axis([-5 15 -5 15 -5 15]);

line([rrs(1,4), rrs(1,4) + rrs(1,1)], [rrs(2,4), rrs(2,4) + rrs(2,1)], [rrs(3,4), rrs(3,4) + rrs(3,1)], 'color', 'b', 'linewidth', 4);
line([rrs(1,4), rrs(1,4) + rrs(1,2)], [rrs(2,4), rrs(2,4) + rrs(2,2)], [rrs(3,4), rrs(3,4) + rrs(3,2)], 'color', 'g', 'linewidth', 4);
line([rrs(1,4), rrs(1,4) + rrs(1,3)], [rrs(2,4), rrs(2,4) + rrs(2,3)], [rrs(3,4), rrs(3,4) + rrs(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.5);
    if i < 5
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Rotacion de 270 en Ru-----
for i=0:270; 
xu=1;
yu=0;
zu=0;
xv=0;
yv=cosd(i);
zv=sind(i);
xw=0;
yw=-sind(i);
zw=cosd(i);
t1=0;
t2=0;
t3=0;
t4=1;
a1=0;
a2=0;
a3=0;

Ru= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrt = rrs*Ru;

grid on
view(135,22) 
axis([-5 15 -5 15 -5 15]);

line([rrt(1,4), rrt(1,4) + rrt(1,1)], [rrt(2,4), rrt(2,4) + rrt(2,1)], [rrt(3,4), rrt(3,4) + rrt(3,1)], 'color', 'b', 'linewidth', 4);
line([rrt(1,4), rrt(1,4) + rrt(1,2)], [rrt(2,4), rrt(2,4) + rrt(2,2)], [rrt(3,4), rrt(3,4) + rrt(3,2)], 'color', 'g', 'linewidth', 4);
line([rrt(1,4), rrt(1,4) + rrt(1,3)], [rrt(2,4), rrt(2,4) + rrt(2,3)], [rrt(3,4), rrt(3,4) + rrt(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.00001);
    if i < 270
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Traslacion de 7 en Rw-----
for i=0:7;
xu=cosd(i);
yu=sind(i);
zu=0;
xv=-sind(i);
yv=cosd(i);
zv=0;
xw=0;
yw=0;
zw=1;
t1=0;
t2=0;
t3=i;
t4=1;
a1=0;
a2=0;
a3=0;

Rw= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rru = rrt*Rw;  
grid on
view(135,22); 
axis([-5 15 -5 15 -5 15]);

line([rru(1,4), rru(1,4) + rru(1,1)], [rru(2,4), rru(2,4) + rru(2,1)], [rru(3,4), rru(3,4) + rru(3,1)], 'color', 'b', 'linewidth', 4);
line([rru(1,4), rru(1,4) + rru(1,2)], [rru(2,4), rru(2,4) + rru(2,2)], [rru(3,4), rru(3,4) + rru(3,2)], 'color', 'g', 'linewidth', 4);
line([rru(1,4), rru(1,4) + rru(1,3)], [rru(2,4), rru(2,4) + rru(2,3)], [rru(3,4), rru(3,4) + rru(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.5);
    if i < 7
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Rotacion de 270 en Ru-----
for i=0:270; 
xu=1;
yu=0;
zu=0;
xv=0;
yv=cosd(i);
zv=sind(i);
xw=0;
yw=-sind(i);
zw=cosd(i);
t1=0;
t2=0;
t3=0;
t4=1;
a1=0;
a2=0;
a3=0;

Ru= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrv = rru*Ru;

grid on
view(135,22) 
axis([-5 15 -5 15 -5 15]);

line([rrv(1,4), rrv(1,4) + rrv(1,1)], [rrv(2,4), rrv(2,4) + rrv(2,1)], [rrv(3,4), rrv(3,4) + rrv(3,1)], 'color', 'b', 'linewidth', 4);
line([rrv(1,4), rrv(1,4) + rrv(1,2)], [rrv(2,4), rrv(2,4) + rrv(2,2)], [rrv(3,4), rrv(3,4) + rrv(3,2)], 'color', 'g', 'linewidth', 4);
line([rrv(1,4), rrv(1,4) + rrv(1,3)], [rrv(2,4), rrv(2,4) + rrv(2,3)], [rrv(3,4), rrv(3,4) + rrv(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.00001); 
    if i < 270
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Traslacion de 5 en Rw-----
for i=0:5;
xu=cosd(i);
yu=sind(i);
zu=0;
xv=-sind(i);
yv=cosd(i);
zv=0;
xw=0;
yw=0;
zw=1;
t1=0;
t2=0;
t3=i;
t4=1;
a1=0;
a2=0;
a3=0;

Rw= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrw = rrv*Rw;  

grid on 
view(135,22); 
axis([-5 15 -5 15 -5 15]);

line([rrw(1,4), rrw(1,4) + rrw(1,1)], [rrw(2,4), rrw(2,4) + rrw(2,1)], [rrw(3,4), rrw(3,4) + rrw(3,1)], 'color', 'b', 'linewidth', 4);
line([rrw(1,4), rrw(1,4) + rrw(1,2)], [rrw(2,4), rrw(2,4) + rrw(2,2)], [rrw(3,4), rrw(3,4) + rrw(3,2)], 'color', 'g', 'linewidth', 4);
line([rrw(1,4), rrw(1,4) + rrw(1,3)], [rrw(2,4), rrw(2,4) + rrw(2,3)], [rrw(3,4), rrw(3,4) + rrw(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.5);
    if i < 5
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Rotacion de 90 en Rv-----
for i = 0:90
xu=cosd(i);
yu=0;
zu=-sind(i);
xv=0;
yv=1;
zv=0;
xw=sind(i);
yw=0;
zw=cosd(i);
t1=0;
t2=0;
t3=0;
t4=1;
a1=0;
a2=0;
a3=0;

Rv= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrx = rrw*Rv;

grid on
view(135,22)
axis([-5 15 -5 15 -5 15]);

line([rrx(1,4), rrx(1,4) + rrx(1,1)], [rrx(2,4), rrx(2,4) + rrx(2,1)], [rrx(3,4), rrx(3,4) + rrx(3,1)], 'color', 'b', 'linewidth', 4);
line([rrx(1,4), rrx(1,4) + rrx(1,2)], [rrx(2,4), rrx(2,4) + rrx(2,2)], [rrx(3,4), rrx(3,4) + rrx(3,2)], 'color', 'g', 'linewidth', 4);
line([rrx(1,4), rrx(1,4) + rrx(1,3)], [rrx(2,4), rrx(2,4) + rrx(2,3)], [rrx(3,4), rrx(3,4) + rrx(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.00001); 
    if  i < 90
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Rotacion de 270 en Ru-----
for i=0:270; 
xu=1;
yu=0;
zu=0;
xv=0;
yv=cosd(i);
zv=sind(i);
xw=0;
yw=-sind(i);
zw=cosd(i);
t1=0;
t2=0;
t3=0;
t4=1;
a1=0;
a2=0;
a3=0;

Ru= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rry = rrx*Ru;

grid on
view(135,22) 
axis([-5 15 -5 15 -5 15]);

line([rry(1,4), rry(1,4) + rry(1,1)], [rry(2,4), rry(2,4) + rry(2,1)], [rry(3,4), rry(3,4) + rry(3,1)], 'color', 'b', 'linewidth', 4);
line([rry(1,4), rry(1,4) + rry(1,2)], [rry(2,4), rry(2,4) + rry(2,2)], [rry(3,4), rry(3,4) + rry(3,2)], 'color', 'g', 'linewidth', 4);
line([rry(1,4), rry(1,4) + rry(1,3)], [rry(2,4), rry(2,4) + rry(2,3)], [rry(3,4), rry(3,4) + rry(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.00001); 
    if i < 270
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Traslacion de 8 en Rw-----
for i=0:8;
xu=cosd(i);
yu=sind(i);
zu=0;
xv=-sind(i);
yv=cosd(i);
zv=0;
xw=0;
yw=0;
zw=1;
t1=0;
t2=0;
t3=i;
t4=1;
a1=0;
a2=0;
a3=0;

Rw= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrz = rry*Rw; 
grid on
view(135,22); 
axis([-5 15 -5 15 -5 15]);

line([rrz(1,4), rrz(1,4) + rrz(1,1)], [rrz(2,4), rrz(2,4) + rrz(2,1)], [rrz(3,4), rrz(3,4) + rrz(3,1)], 'color', 'b', 'linewidth', 4);
line([rrz(1,4), rrz(1,4) + rrz(1,2)], [rrz(2,4), rrz(2,4) + rrz(2,2)], [rrz(3,4), rrz(3,4) + rrz(3,2)], 'color', 'g', 'linewidth', 4);
line([rrz(1,4), rrz(1,4) + rrz(1,3)], [rrz(2,4), rrz(2,4) + rrz(2,3)], [rrz(3,4), rrz(3,4) + rrz(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.5); 
    if i < 8
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Rotacion de 90 en Ru-----
for i=0:90; 
xu=1;
yu=0;
zu=0;
xv=0;
yv=cosd(i);
zv=sind(i);
xw=0;
yw=-sind(i);
zw=cosd(i);
t1=0;
t2=0;
t3=0;
t4=1;
a1=0;
a2=0;
a3=0;

Ru= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrra = rrz*Ru;

grid on
view(135,22) 
axis([-5 15 -5 15 -5 15]);

line([rrra(1,4), rrra(1,4) + rrra(1,1)], [rrra(2,4), rrra(2,4) + rrra(2,1)], [rrra(3,4), rrra(3,4) + rrra(3,1)], 'color', 'b', 'linewidth', 4);
line([rrra(1,4), rrra(1,4) + rrra(1,2)], [rrra(2,4), rrra(2,4) + rrra(2,2)], [rrra(3,4), rrra(3,4) + rrra(3,2)], 'color', 'g', 'linewidth', 4);
line([rrra(1,4), rrra(1,4) + rrra(1,3)], [rrra(2,4), rrra(2,4) + rrra(2,3)], [rrra(3,4), rrra(3,4) + rrra(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.00001);
    if i < 90
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Traslacion de 6 en Rw-----
for i=0:6;
xu=cosd(i);
yu=sind(i);
zu=0;
xv=-sind(i);
yv=cosd(i);
zv=0;
xw=0;
yw=0;
zw=1;
t1=0;
t2=0;
t3=i;
t4=1;
a1=0;
a2=0;
a3=0;

Rw= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrrb = rrra*Rw; 

grid on 
view(135,22); 
axis([-5 15 -5 15 -5 15]);

line([rrrb(1,4), rrrb(1,4) + rrrb(1,1)], [rrrb(2,4), rrrb(2,4) + rrrb(2,1)], [rrrb(3,4), rrrb(3,4) + rrrb(3,1)], 'color', 'b', 'linewidth', 4);
line([rrrb(1,4), rrrb(1,4) + rrrb(1,2)], [rrrb(2,4), rrrb(2,4) + rrrb(2,2)], [rrrb(3,4), rrrb(3,4) + rrrb(3,2)], 'color', 'g', 'linewidth', 4);
line([rrrb(1,4), rrrb(1,4) + rrrb(1,3)], [rrrb(2,4), rrrb(2,4) + rrrb(2,3)], [rrrb(3,4), rrrb(3,4) + rrrb(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.5);
    if i < 6
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Rotacion de 90 en Ru-----
for i=0:90; 
xu=1;
yu=0;
zu=0;
xv=0;
yv=cosd(i);
zv=sind(i);
xw=0;
yw=-sind(i);
zw=cosd(i);
t1=0;
t2=0;
t3=0;
t4=1;
a1=0;
a2=0;
a3=0;

Ru= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrrc = rrrb*Ru;

grid on
view(135,22)
axis([-5 15 -5 15 -5 15]);

line([rrrc(1,4), rrrc(1,4) + rrrc(1,1)], [rrrc(2,4), rrrc(2,4) + rrrc(2,1)], [rrrc(3,4), rrrc(3,4) + rrrc(3,1)], 'color', 'b', 'linewidth', 4);
line([rrrc(1,4), rrrc(1,4) + rrrc(1,2)], [rrrc(2,4), rrrc(2,4) + rrrc(2,2)], [rrrc(3,4), rrrc(3,4) + rrrc(3,2)], 'color', 'g', 'linewidth', 4);
line([rrrc(1,4), rrrc(1,4) + rrrc(1,3)], [rrrc(2,4), rrrc(2,4) + rrrc(2,3)], [rrrc(3,4), rrrc(3,4) + rrrc(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.00001); 
    if i < 90
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Traslacion de 1 en Rw-----
for i=0:1;
xu=cosd(i);
yu=sind(i);
zu=0;
xv=-sind(i);
yv=cosd(i);
zv=0;
xw=0;
yw=0;
zw=1;
t1=0;
t2=0;
t3=i;
t4=1;
a1=0;
a2=0;
a3=0;

Rw= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrrd = rrrc*Rw; 

grid on 
view(135,22);
axis([-5 15 -5 15 -5 15]);

line([rrrd(1,4), rrrd(1,4) + rrrd(1,1)], [rrrd(2,4), rrrd(2,4) + rrrd(2,1)], [rrrd(3,4), rrrd(3,4) + rrrd(3,1)], 'color', 'b', 'linewidth', 4);
line([rrrd(1,4), rrrd(1,4) + rrrd(1,2)], [rrrd(2,4), rrrd(2,4) + rrrd(2,2)], [rrrd(3,4), rrrd(3,4) + rrrd(3,2)], 'color', 'g', 'linewidth', 4);
line([rrrd(1,4), rrrd(1,4) + rrrd(1,3)], [rrrd(2,4), rrrd(2,4) + rrrd(2,3)], [rrrd(3,4), rrrd(3,4) + rrrd(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.5);
    if i < 1
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Rotacion de 45 en Ru-----
for i=0:45; 
xu=1;
yu=0;
zu=0;
xv=0;
yv=cosd(i);
zv=sind(i);
xw=0;
yw=-sind(i);
zw=cosd(i);
t1=0;
t2=0;
t3=0;
t4=1;
a1=0;
a2=0;
a3=0;

Ru= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrre = rrrd*Ru;

grid on
view(135,22) 
axis([-5 15 -5 15 -5 15]);

line([rrre(1,4), rrre(1,4) + rrre(1,1)], [rrre(2,4), rrre(2,4) + rrre(2,1)], [rrre(3,4), rrre(3,4) + rrre(3,1)], 'color', 'b', 'linewidth', 4);
line([rrre(1,4), rrre(1,4) + rrre(1,2)], [rrre(2,4), rrre(2,4) + rrre(2,2)], [rrre(3,4), rrre(3,4) + rrre(3,2)], 'color', 'g', 'linewidth', 4);
line([rrre(1,4), rrre(1,4) + rrre(1,3)], [rrre(2,4), rrre(2,4) + rrre(2,3)], [rrre(3,4), rrre(3,4) + rrre(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.00001); 
    if i < 45
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Traslacion de 9 en Rw-----
for i=0:9;
xu=cosd(i);
yu=sind(i);
zu=0;
xv=-sind(i);
yv=cosd(i);
zv=0;
xw=0;
yw=0;
zw=1;
t1=0;
t2=0;
t3=i;
t4=1;
a1=0;
a2=0;
a3=0;

Rw= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrrf = rrre*Rw; 

grid on
view(135,22);
axis([-5 15 -5 15 -5 15]);

line([rrrf(1,4), rrrf(1,4) + rrrf(1,1)], [rrrf(2,4), rrrf(2,4) + rrrf(2,1)], [rrrf(3,4), rrrf(3,4) + rrrf(3,1)], 'color', 'b', 'linewidth', 4);
line([rrrf(1,4), rrrf(1,4) + rrrf(1,2)], [rrrf(2,4), rrrf(2,4) + rrrf(2,2)], [rrrf(3,4), rrrf(3,4) + rrrf(3,2)], 'color', 'g', 'linewidth', 4);
line([rrrf(1,4), rrrf(1,4) + rrrf(1,3)], [rrrf(2,4), rrrf(2,4) + rrrf(2,3)], [rrrf(3,4), rrrf(3,4) + rrrf(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.5);
    if i < 9
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Rotacion de 315 en Ru-----
for i=0:315; 
xu=1;
yu=0;
zu=0;
xv=0;
yv=cosd(i);
zv=sind(i);
xw=0;
yw=-sind(i);
zw=cosd(i);
t1=0;
t2=0;
t3=0;
t4=1;
a1=0;
a2=0;
a3=0;

Ru= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrrg = rrrf*Ru;

grid on
view(135,22) 
axis([-5 15 -5 15 -5 15]);

line([rrrg(1,4), rrrg(1,4) + rrrg(1,1)], [rrrg(2,4), rrrg(2,4) + rrrg(2,1)], [rrrg(3,4), rrrg(3,4) + rrrg(3,1)], 'color', 'b', 'linewidth', 4);
line([rrrg(1,4), rrrg(1,4) + rrrg(1,2)], [rrrg(2,4), rrrg(2,4) + rrrg(2,2)], [rrrg(3,4), rrrg(3,4) + rrrg(3,2)], 'color', 'g', 'linewidth', 4);
line([rrrg(1,4), rrrg(1,4) + rrrg(1,3)], [rrrg(2,4), rrrg(2,4) + rrrg(2,3)], [rrrg(3,4), rrrg(3,4) + rrrg(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.00001); 
    if i < 315
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Rotacion de 90 en Rv-----
for i = 0:90
xu=cosd(i);
yu=0;
zu=-sind(i);
xv=0;
yv=1;
zv=0;
xw=sind(i);
yw=0;
zw=cosd(i);
t1=0;
t2=0;
t3=0;
t4=1;
a1=0;
a2=0;
a3=0;

Rv= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrrh = rrrg*Rv;

grid on
view(135,22)
axis([-5 15 -5 15 -5 15]);

line([rrrh(1,4), rrrh(1,4) + rrrh(1,1)], [rrrh(2,4), rrrh(2,4) + rrrh(2,1)], [rrrh(3,4), rrrh(3,4) + rrrh(3,1)], 'color', 'b', 'linewidth', 4);
line([rrrh(1,4), rrrh(1,4) + rrrh(1,2)], [rrrh(2,4), rrrh(2,4) + rrrh(2,2)], [rrrh(3,4), rrrh(3,4) + rrrh(3,2)], 'color', 'g', 'linewidth', 4);
line([rrrh(1,4), rrrh(1,4) + rrrh(1,3)], [rrrh(2,4), rrrh(2,4) + rrrh(2,3)], [rrrh(3,4), rrrh(3,4) + rrrh(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.00001); 
    if  i < 90
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Traslacion de 5 en Rw-----
for i=0:5;
xu=cosd(i);
yu=sind(i);
zu=0;
xv=-sind(i);
yv=cosd(i);
zv=0;
xw=0;
yw=0;
zw=1;
t1=0;
t2=0;
t3=i;
t4=1;
a1=0;
a2=0;
a3=0;

Rw= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrri = rrrh*Rw; 

grid on 
view(135,22); 
axis([-5 15 -5 15 -5 15]);

line([rrri(1,4), rrri(1,4) + rrri(1,1)], [rrri(2,4), rrri(2,4) + rrri(2,1)], [rrri(3,4), rrri(3,4) + rrri(3,1)], 'color', 'b', 'linewidth', 4);
line([rrri(1,4), rrri(1,4) + rrri(1,2)], [rrri(2,4), rrri(2,4) + rrri(2,2)], [rrri(3,4), rrri(3,4) + rrri(3,2)], 'color', 'g', 'linewidth', 4);
line([rrri(1,4), rrri(1,4) + rrri(1,3)], [rrri(2,4), rrri(2,4) + rrri(2,3)], [rrri(3,4), rrri(3,4) + rrri(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.5);
    if i < 5
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Rotacion de 90 en Rv-----
for i = 0:90
xu=cosd(i);
yu=0;
zu=-sind(i);
xv=0;
yv=1;
zv=0;
xw=sind(i);
yw=0;
zw=cosd(i);
t1=0;
t2=0;
t3=0;
t4=1;
a1=0;
a2=0;
a3=0;

Rv= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrrj = rrri*Rv;

grid on
view(135,22) 
axis([-5 15 -5 15 -5 15]);

line([rrrj(1,4), rrrj(1,4) + rrrj(1,1)], [rrrj(2,4), rrrj(2,4) + rrrj(2,1)], [rrrj(3,4), rrrj(3,4) + rrrj(3,1)], 'color', 'b', 'linewidth', 4);
line([rrrj(1,4), rrrj(1,4) + rrrj(1,2)], [rrrj(2,4), rrrj(2,4) + rrrj(2,2)], [rrrj(3,4), rrrj(3,4) + rrrj(3,2)], 'color', 'g', 'linewidth', 4);
line([rrrj(1,4), rrrj(1,4) + rrrj(1,3)], [rrrj(2,4), rrrj(2,4) + rrrj(2,3)], [rrrj(3,4), rrrj(3,4) + rrrj(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.00001); 
    if  i < 90
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Rotacion de 315 en Ru-----
for i=0:315; 
xu=1;
yu=0;
zu=0;
xv=0;
yv=cosd(i);
zv=sind(i);
xw=0;
yw=-sind(i);
zw=cosd(i);
t1=0;
t2=0;
t3=0;
t4=1;
a1=0;
a2=0;
a3=0;

Ru= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrrk = rrrj*Ru;

grid on
view(135,22) 
axis([-5 15 -5 15 -5 15]);

line([rrrk(1,4), rrrk(1,4) + rrrk(1,1)], [rrrk(2,4), rrrk(2,4) + rrrk(2,1)], [rrrk(3,4), rrrk(3,4) + rrrk(3,1)], 'color', 'b', 'linewidth', 4);
line([rrrk(1,4), rrrk(1,4) + rrrk(1,2)], [rrrk(2,4), rrrk(2,4) + rrrk(2,2)], [rrrk(3,4), rrrk(3,4) + rrrk(3,2)], 'color', 'g', 'linewidth', 4);
line([rrrk(1,4), rrrk(1,4) + rrrk(1,3)], [rrrk(2,4), rrrk(2,4) + rrrk(2,3)], [rrrk(3,4), rrrk(3,4) + rrrk(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.00001); 
    if i < 315
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Traslacion de 9 en Rw-----
for i=0:9;
xu=cosd(i);
yu=sind(i);
zu=0;
xv=-sind(i);
yv=cosd(i);
zv=0;
xw=0;
yw=0;
zw=1;
t1=0;
t2=0;
t3=i;
t4=1;
a1=0;
a2=0;
a3=0;

Rw= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrrl = rrrk*Rw;  

grid on 
view(135,22); 
axis([-5 15 -5 15 -5 15]);

line([rrrl(1,4), rrrl(1,4) + rrrl(1,1)], [rrrl(2,4), rrrl(2,4) + rrrl(2,1)], [rrrl(3,4), rrrl(3,4) + rrrl(3,1)], 'color', 'b', 'linewidth', 4);
line([rrrl(1,4), rrrl(1,4) + rrrl(1,2)], [rrrl(2,4), rrrl(2,4) + rrrl(2,2)], [rrrl(3,4), rrrl(3,4) + rrrl(3,2)], 'color', 'g', 'linewidth', 4);
line([rrrl(1,4), rrrl(1,4) + rrrl(1,3)], [rrrl(2,4), rrrl(2,4) + rrrl(2,3)], [rrrl(3,4), rrrl(3,4) + rrrl(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.5); 
    if i < 9
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.

%-----Rotacion de 45 en Ru-----
for i=0:45; 
xu=1;
yu=0;
zu=0;
xv=0;
yv=cosd(i);
zv=sind(i);
xw=0;
yw=-sind(i);
zw=cosd(i);
t1=0;
t2=0;
t3=0;
t4=1;
a1=0;
a2=0;
a3=0;

Ru= [xu xv xw t1;
    yu yv yw t2;
    zu zv zw t3
    a1 a2 a3 t4];

rrrm = rrrl*Ru;

grid on
view(135,22) 
axis([-5 15 -5 15 -5 15]);

line([rrrm(1,4), rrrm(1,4) + rrrm(1,1)], [rrrm(2,4), rrrm(2,4) + rrrm(2,1)], [rrrm(3,4), rrrm(3,4) + rrrm(3,1)], 'color', 'b', 'linewidth', 4);
line([rrrm(1,4), rrrm(1,4) + rrrm(1,2)], [rrrm(2,4), rrrm(2,4) + rrrm(2,2)], [rrrm(3,4), rrrm(3,4) + rrrm(3,2)], 'color', 'g', 'linewidth', 4);
line([rrrm(1,4), rrrm(1,4) + rrrm(1,3)], [rrrm(2,4), rrrm(2,4) + rrrm(2,3)], [rrrm(3,4), rrrm(3,4) + rrrm(3,3)], 'color', 'r', 'linewidth', 4);
pause (0.00001); 
    if i < 45
        delete(findobj(gca, 'Color', 'b')); % Borra las líneas azules (eje X)
        delete(findobj(gca, 'Color', 'g')); % Borra las líneas verdes (eje Y)
        delete(findobj(gca, 'Color', 'r')); % Borra las líneas rojas (eje Z)
end %Fin del condicional.
end %Final del primer incremento.



